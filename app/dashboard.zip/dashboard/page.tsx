"use client";

import AdminDashboard from './admin-dashboard';

export default function DashboardPage() {
  return <AdminDashboard />;
}
