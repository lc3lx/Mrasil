import { ContractsContent } from "@/components/v7/pages/contracts-content"

export default function ContractsPage() {
  return <ContractsContent />
}
