import { AddContractForm } from "@/app/contracts/add/add-contract-form"

export default function AddContractPage() {
  return <AddContractForm />
}
