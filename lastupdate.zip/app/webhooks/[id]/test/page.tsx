import { WebhookTestPage } from "@/app/webhooks/[id]/test/webhook-test-page"

export default function WebhookTest() {
  return <WebhookTestPage />
}
