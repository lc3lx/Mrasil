import AdvancedShippingConditions from "./advanced-shipping-conditions"

export default function AdvancedShippingConditionsPage() {
  return <AdvancedShippingConditions />
}
