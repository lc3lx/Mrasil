export default function InvoicesLoading() {
  return (
    <div className="w-full h-screen flex items-center justify-center">
      <div className="v7-loading-spinner"></div>
    </div>
  )
}
