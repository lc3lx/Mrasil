
#!/bin/bash

# Install framer-motion for animations
npm install framer-motion

echo "Dependencies installed successfully!"
