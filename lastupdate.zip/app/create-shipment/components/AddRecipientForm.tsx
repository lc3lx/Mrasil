import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { SearchableCitySelect } from "./SearchableCitySelect";
import { Mail, Phone, MapPin, User } from "lucide-react";

const cities = [
  "الرياض",
  "جدة",
  "مكة",
  "المدينة",
  "الدمام",
  "الخبر",
  "الطائف",
  "تبوك",
  "بريدة",
  "خميس مشيط",
  "الهفوف",
  "المبرز",
  "حفر الباطن",
  "حائل",
  "نجران",
  "الجبيل",
  "أبها",
  "ينبع",
  "عرعر",
  "عنيزة",
  "سكاكا",
  "جازان",
  "القطيف",
  "الباحة",
  "بيشة",
  "الرس",
];

interface AddRecipientFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => Promise<void>;
  isLoading?: boolean;
  error?: any;
  initialValues?: {
    clientName?: string;
    clientAddress?: string;
    district?: string;
    city?: string;
    country?: string;
    clientEmail?: string;
    clientPhone?: string;
    customer?: string;
  };
}

export function AddRecipientForm({
  isOpen,
  onClose,
  onSubmit,
  isLoading = false,
  error,
  initialValues,
}: AddRecipientFormProps) {
  const [form, setForm] = useState({
    clientName: initialValues?.clientName || "",
    clientAddress: initialValues?.clientAddress || "",
    district: initialValues?.district || "",
    city: initialValues?.city || "",
    country: initialValues?.country || "",
    clientEmail: initialValues?.clientEmail || "",
    clientPhone: initialValues?.clientPhone || "",
    customer: initialValues?.customer || "",
  });
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleCityChange = (value: string) => {
    setForm({ ...form, city: value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    // Combine country and city for clientAddress, and set district to '----'
    const payload = {
      ...form,
      clientAddress: `${form.country}, ${form.city}`,
      district: "----",
    };
    await onSubmit(payload);
    setSubmitting(false);
  };

  const handleClose = () => {
    setForm({
      clientName: "",
      clientAddress: "",
      district: "",
      city: "",
      country: "",
      clientEmail: "",
      clientPhone: "",
      customer: "",
    });
    onClose();
  };
  const [weightFocused, setWeightFocused] = useState(false);
  const [descFocused, setDescFocused] = useState(false);
  const [weightFocusedA, setWeightFocusedA] = useState(false);
  const [descFocusedA, setDescFocusedA] = useState(false);
  const [weightFocusedAA, setWeightFocusedAA] = useState(false);
  const [descFocusedAA, setDescFocusedAA] = useState(false);
  const [weightFocusedAAA, setWeightFocusedAAA] = useState(false);
  const [descFocusedAAA, setDescFocusedAAA] = useState(false);
  const [weightFocusedM, setWeightFocusedM] = useState(false);
  const [descFocusedM, setDescFocusedM] = useState(false);

// Dedicated change handler for textarea to fix lint error
type TextAreaEvent = React.ChangeEvent<HTMLTextAreaElement>;
const handleChangeTextArea = (e: TextAreaEvent) => {
  const { name, value } = e.target;
  setForm((prev) => ({ ...prev, [name]: value }));
};
  return (
  <Dialog open={isOpen} onOpenChange={handleClose}>
    <DialogContent className="bg-transparent shadow-none p-0 max-w-lg w-full flex items-center justify-center">
      <div className="bg-white dark:bg-gray-800 p-8 rounded-xl shadow-2xl max-w-md w-full relative overflow-hidden" style={{ opacity: 1, transform: "none" }}>
        <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-br from-[#3498db]/5 to-transparent rounded-full transform translate-x-20 -translate-y-20"></div>
        <div className="absolute bottom-0 left-0 w-40 h-40 bg-gradient-to-br from-[#3498db]/5 to-transparent rounded-full transform -translate-x-20 translate-y-20"></div>
        <div className="relative">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-2xl font-bold text-gray-800 dark:text-gray-100 flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-[#3498db]/10 flex items-center justify-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-user h-4 w-4 text-[#3498db]"
                >
                  <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path>
                  <circle cx="12" cy="7" r="4"></circle>
                </svg>
              </div>
              إضافة عميل جديد
            </h3>
            <button
              className="ring-offset-background focus-visible:outline-hidden focus-visible:ring-ring inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 hover:text-accent-foreground h-8 w-8 rounded-full hover:bg-[#3498db]/10"
              onClick={handleClose}
              type="button"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-x h-5 w-5"
              >
                <path d="M18 6 6 18"></path>
                <path d="m6 6 12 12"></path>
              </svg>
            </button>
          </div>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex items-center gap-2 text-sm font-medium" htmlFor="clientName">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-user h-4 w-4 text-[#3498db]"
                >
                  <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path>
                  <circle cx="12" cy="7" r="4"></circle>
                </svg>
                اسم العميل
              </label>
              <div className="v7-neu-input-container mt-1 relative overflow-hidden group">
                <input
                  className="flex h-10 w-full rounded-lg border-[0.5px] border-transparent bg-background/5 px-3 py-2 text-sm shadow-[inset_0_2px_4px_rgba(0,0,0,0.08)] hover:shadow-[inset_0_2px_5px_rgba(0,0,0,0.12)] transition-all duration-300 ease-in-out file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground/60 focus-visible:outline-none focus-visible:border-input/20 focus-visible:bg-gradient-to-b focus-visible:from-background/10 focus-visible:to-background/5 focus-visible:shadow-[inset_0_2px_6px_rgba(0,0,0,0.15)] hover:border-input/20 disabled:cursor-not-allowed disabled:opacity-60 disabled:bg-muted/20 disabled:shadow-none v7-neu-input"
                  placeholder="الاسم الكامل للعميل"
                  id="clientName"
                  name="clientName"
                  value={form.clientName}
                  onChange={handleChange}
                  required
                />
                <div className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-[#3498db] to-[#2980b9] transform scale-x-0 group-focus-within:scale-x-100 transition-transform duration-300 origin-left"></div>
              </div>
            </div>
            <div>
              <label className="peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex items-center gap-2 text-sm font-medium" htmlFor="clientPhone">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-phone h-4 w-4 text-[#3498db]"
                >
                  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                </svg>
                رقم الهاتف
              </label>
              <div className="v7-neu-input-container mt-1 relative overflow-hidden group">
                <input
                  className="flex h-10 w-full rounded-lg border-[0.5px] border-transparent bg-background/5 px-3 py-2 text-sm shadow-[inset_0_2px_4px_rgba(0,0,0,0.08)] hover:shadow-[inset_0_2px_5px_rgba(0,0,0,0.12)] transition-all duration-300 ease-in-out file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground/60 focus-visible:outline-none focus-visible:border-input/20 focus-visible:bg-gradient-to-b focus-visible:from-background/10 focus-visible:to-background/5 focus-visible:shadow-[inset_0_2px_6px_rgba(0,0,0,0.15)] hover:border-input/20 disabled:cursor-not-allowed disabled:opacity-60 disabled:bg-muted/20 disabled:shadow-none v7-neu-input"
                  placeholder="05xxxxxxxx"
                  id="clientPhone"
                  name="clientPhone"
                  value={form.clientPhone}
                  onChange={handleChange}
                  required
                />
                <div className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-[#3498db] to-[#2980b9] transform scale-x-0 group-focus-within:scale-x-100 transition-transform duration-300 origin-left"></div>
              </div>
            </div>
            <div>
              <label className="peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex items-center gap-2 text-sm font-medium" htmlFor="clientEmail">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-mail h-4 w-4 text-[#3498db]"
                >
                  <rect width="20" height="16" x="2" y="4" rx="2"></rect>
                  <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path>
                </svg>
                البريد الإلكتروني
              </label>
              <div className="v7-neu-input-container mt-1 relative overflow-hidden group">
                <input
                  className="flex h-10 w-full rounded-lg border-[0.5px] border-transparent bg-background/5 px-3 py-2 text-sm shadow-[inset_0_2px_4px_rgba(0,0,0,0.08)] hover:shadow-[inset_0_2px_5px_rgba(0,0,0,0.12)] transition-all duration-300 ease-in-out file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground/60 focus-visible:outline-none focus-visible:border-input/20 focus-visible:bg-gradient-to-b focus-visible:from-background/10 focus-visible:to-background/5 focus-visible:shadow-[inset_0_2px_6px_rgba(0,0,0,0.15)] hover:border-input/20 disabled:cursor-not-allowed disabled:opacity-60 disabled:bg-muted/20 disabled:shadow-none v7-neu-input"
                  placeholder="example@domain.com"
                  id="clientEmail"
                  name="clientEmail"
                  value={form.clientEmail}
                  onChange={handleChange}
                  required
                  type="email"
                />
                <div className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-[#3498db] to-[#2980b9] transform scale-x-0 group-focus-within:scale-x-100 transition-transform duration-300 origin-left"></div>
              </div>
            </div>
            <div>
              <label className="peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex items-center gap-2 text-sm font-medium" htmlFor="city">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-map-pin h-4 w-4 text-[#3498db]"
                >
                  <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path>
                  <circle cx="12" cy="10" r="3"></circle>
                </svg>
                المدينة
              </label>
              <div className="v7-neu-input-container mt-1 relative overflow-hidden group">
                <SearchableCitySelect
                  value={form.city}
                  onChange={handleCityChange}
                  cities={cities}
                  placeholder="اختر المدينة"
                />
                <div className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-[#3498db] to-[#2980b9] transform scale-x-0 group-focus-within:scale-x-100 transition-transform duration-300 origin-left"></div>
              </div>
            </div>
            <div>
              <label className="peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex items-center gap-2 text-sm font-medium" htmlFor="clientAddress">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-file-text h-4 w-4 text-[#3498db]"
                >
                  <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"></path>
                  <path d="M14 2v4a2 2 0 0 0 2 2h4"></path>
                  <path d="M10 9H8"></path>
                  <path d="M16 13H8"></path>
                  <path d="M16 17H8"></path>
                </svg>
                العنوان التفصيلي
              </label>
              <div className="v7-neu-input-container mt-1 relative overflow-hidden group">
                <textarea
  className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 v7-neu-input"
  id="clientAddress"
  name="clientAddress"
  placeholder="الحي، الشارع، رقم المبنى..."
  value={form.clientAddress}
  onChange={handleChangeTextArea}
></textarea>
                <div className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-[#3498db] to-[#2980b9] transform scale-x-0 group-focus-within:scale-x-100 transition-transform duration-300 origin-left"></div>
              </div>
            </div>
            {error && (
              <div className="text-red-500 text-sm">
                {typeof error === "string" ? error : "حدث خطأ أثناء إضافة العميل"}
              </div>
            )}
            <div className="flex gap-3 mt-6">
              <button
                type="button"
                className="ring-offset-background focus-visible:outline-hidden focus-visible:ring-ring inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border-input bg-background hover:bg-accent hover:text-accent-foreground border h-10 px-4 py-2 flex-1 v7-neu-button-flat"
                onClick={handleClose}
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="ring-offset-background focus-visible:outline-hidden focus-visible:ring-ring inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2 flex-1 v7-neu-button-accent bg-gradient-to-r from-[#3498db] to-[#2980b9] relative overflow-hidden group"
                disabled={isLoading || submitting}
              >
                <span className="relative z-10">
                  {isLoading || submitting ? "جاري الإضافة..." : "حفظ العميل"}
                </span>
                <span className="absolute inset-0 bg-gradient-to-r from-[#2980b9] to-[#3498db] opacity-0 group-hover:opacity-100 transition-opacity duration-300"></span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </DialogContent>
  </Dialog>
);
}
