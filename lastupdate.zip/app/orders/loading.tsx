import { V7LoadingScreen } from "@/components/v7/v7-loading-screen"

export default function Loading() {
  return <V7LoadingScreen title="جاري تحميل الطلبات..." />
}
