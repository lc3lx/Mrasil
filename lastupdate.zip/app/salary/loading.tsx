export default function Loading() {
  return <div className="p-8 text-center">جاري تحميل بيانات الرواتب...</div>
} 